import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { OmniScopeStudio } from './components/OmniScopeStudio';
import { CitationTimeline } from './components/CitationTimeline';
import { GrantStudio } from './components/GrantStudio';
import { HeroSection } from './components/HeroSection';
import { UniversalBackground } from './components/UniversalBackground';
import { DatasetInfo, ArchipelagoData, CitationData, ResearchGap, NarratedGap, PipelineProgressEvent, Points3DData } from './types';

// Stages definition
const STAGES = ['hero', 'archipelago', 'timeline', 'grant'] as const;
type StageId = typeof STAGES[number];

const STAGE_LABELS: Record<StageId, string> = {
  hero: '00 Hero Observatory',
  archipelago: '01 Epistemic Map',
  timeline: '02 Citation Lineage',
  grant: '03 AI Grant Studio',
};

const STAGE_PROGRESS: Record<StageId, number> = {
  hero: 0.00,
  archipelago: 0.33,
  timeline: 0.66,
  grant: 1.00,
};

export const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<'hero' | 'studio'>('hero');
  const [datasets, setDatasets] = useState<DatasetInfo[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<string>('');
  const [activeTab, setActiveTab] = useState<StageId>('hero');
  const [points3dData, setPoints3dData] = useState<Points3DData | null>(null);
  const [archipelagoData, setArchipelagoData] = useState<ArchipelagoData | null>(null);
  const [citationData, setCitationData] = useState<CitationData | null>(null);
  const [detectedGaps, setDetectedGaps] = useState<ResearchGap[]>([]);
  const [narratedGaps, setNarratedGaps] = useState<NarratedGap[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedClusterId, setSelectedClusterId] = useState<string>('');
  const [activeLayer, setActiveLayer] = useState<1 | 2 | 3>(1);
  const [progressEvents, setProgressEvents] = useState<PipelineProgressEvent[]>([]);
  const [selectedGapTitle, setSelectedGapTitle] = useState('');
  const [pipelineError, setPipelineError] = useState<string | null>(null);

  // Discrete Stage Engine
  const [stageIndex, setStageIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  // Visibilities of each stage (0: hero, 1: archipelago, 2: timeline, 3: grant)
  // 'active': fully visible & interactive
  // 'exiting': fading out
  // 'entering': fading in
  // 'hidden': display none
  type StageDisplayState = 'active' | 'exiting' | 'entering' | 'hidden';
  const [stageStates, setStageStates] = useState<StageDisplayState[]>(['active', 'hidden', 'hidden', 'hidden']);

  const stageIndexRef = useRef(0);
  useEffect(() => { stageIndexRef.current = stageIndex; }, [stageIndex]);

  const isAnimatingRef = useRef(false);
  const accumulatedDeltaRef = useRef(0);
  const deltaResetTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const transitionTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const clearTransitionTimers = () => {
    transitionTimersRef.current.forEach(t => clearTimeout(t));
    transitionTimersRef.current = [];
  };

  // Coordinated Stage Navigation
  const goToStage = useCallback((targetIndex: number) => {
    if (isAnimatingRef.current) return;
    const currentIndex = stageIndexRef.current;
    if (targetIndex === currentIndex) return;
    if (targetIndex < 0 || targetIndex >= STAGES.length) return;

    isAnimatingRef.current = true;
    setIsTransitioning(true);
    accumulatedDeltaRef.current = 0;
    clearTransitionTimers();

    const fromStage = STAGES[currentIndex];
    const toStage = STAGES[targetIndex];

    // SCENARIO 1: Hero -> Epistemic Map (2.4s Coordinated Immersive Formation)
    if (currentIndex === 0 && targetIndex === 1) {
      // 1. Hero fades out immediately
      setStageStates(['exiting', 'hidden', 'hidden', 'hidden']);
      setViewMode('studio');
      setActiveTab('archipelago');

      // 2. At t = 400ms: Hero is hidden. The WebGL particle flight is now the sole hero in view.
      const t1 = setTimeout(() => {
        setStageStates(['hidden', 'hidden', 'hidden', 'hidden']);
      }, 400);

      // 3. At t = 1400ms: Particles have formed into clusters. OmniScopeStudio mounts with entry animation.
      const t2 = setTimeout(() => {
        setStageIndex(1);
        setStageStates(['hidden', 'entering', 'hidden', 'hidden']);
      }, 1400);

      // 4. At t = 2400ms: Fully settled and interactive.
      const t3 = setTimeout(() => {
        setStageStates(['hidden', 'active', 'hidden', 'hidden']);
        isAnimatingRef.current = false;
        setIsTransitioning(false);
      }, 2400);

      transitionTimersRef.current = [t1, t2, t3];
      return;
    }

    // SCENARIO 2: Return to Hero (from Epistemic, Citation Lineage, or Grant Studio)
    if (targetIndex === 0) {
      setStageStates(prev => {
        const next = prev.map(() => 'hidden') as StageDisplayState[];
        next[currentIndex] = 'exiting';
        return next;
      });
      setViewMode('hero');
      setActiveTab('hero');

      const t1 = setTimeout(() => {
        setStageStates(['hidden', 'hidden', 'hidden', 'hidden']);
      }, 400);

      const t2 = setTimeout(() => {
        setStageIndex(0);
        setStageStates(['entering', 'hidden', 'hidden', 'hidden']);
      }, 1500);

      const t3 = setTimeout(() => {
        setStageStates(['active', 'hidden', 'hidden', 'hidden']);
        isAnimatingRef.current = false;
        setIsTransitioning(false);
      }, 2400);

      transitionTimersRef.current = [t1, t2, t3];
      return;
    }

    // SCENARIO 3: Standard Fast Clean Cross-Fades (Epistemic <-> Timeline <-> Grant)
    // Exit current stage
    setStageStates(prev => {
      const next = [...prev] as StageDisplayState[];
      next[currentIndex] = 'exiting';
      return next;
    });

    setActiveTab(toStage);
    setViewMode(targetIndex === 0 ? 'hero' : 'studio');

    // After current stage fades out (300ms), hide it and enter target stage
    const t1 = setTimeout(() => {
      setStageIndex(targetIndex);
      setStageStates(prev => {
        const next = [...prev] as StageDisplayState[];
        next[currentIndex] = 'hidden';
        next[targetIndex] = 'entering';
        return next;
      });
    }, 300);

    // After target stage settles (750ms total), lock in active state
    const t2 = setTimeout(() => {
      setStageStates(prev => {
        const next = prev.map(() => 'hidden') as StageDisplayState[];
        next[targetIndex] = 'active';
        return next;
      });
      isAnimatingRef.current = false;
      setIsTransitioning(false);
    }, 800);

    transitionTimersRef.current = [t1, t2];
  }, []);

  // Wheel Handler: Discrete Gestural Staging with Boundary Detection
  const handleWheel = useCallback((e: WheelEvent) => {
    if (isAnimatingRef.current) {
      e.preventDefault();
      return;
    }

    // Check if user is scrolling inside an internal scrollable panel (like paper list or grant text)
    const target = e.target as HTMLElement | null;
    const scrollableParent = target?.closest('.overflow-y-auto, .custom-scrollbar, .research-instrument-panel, [data-scrollable]');
    if (scrollableParent) {
      const { scrollTop, scrollHeight, clientHeight } = scrollableParent;
      const isAtTop = scrollTop <= 2;
      const isAtBottom = scrollTop + clientHeight >= scrollHeight - 2;

      // If scrolling down and can scroll further, don't hijack
      if (e.deltaY > 0 && !isAtBottom) return;
      // If scrolling up and can scroll further, don't hijack
      if (e.deltaY < 0 && !isAtTop) return;
    }

    e.preventDefault();

    // Accumulate scroll delta with automatic decay
    accumulatedDeltaRef.current += e.deltaY;

    if (deltaResetTimeoutRef.current) clearTimeout(deltaResetTimeoutRef.current);
    deltaResetTimeoutRef.current = setTimeout(() => {
      accumulatedDeltaRef.current = 0;
    }, 300);

    const THRESHOLD = 220;
    if (accumulatedDeltaRef.current >= THRESHOLD) {
      accumulatedDeltaRef.current = 0;
      goToStage(stageIndexRef.current + 1);
    } else if (accumulatedDeltaRef.current <= -THRESHOLD) {
      accumulatedDeltaRef.current = 0;
      goToStage(stageIndexRef.current - 1);
    }
  }, [goToStage]);

  // Touch Handlers
  const handleTouchStart = useCallback((e: TouchEvent) => {
    touchStartYRef.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    if (touchStartYRef.current === null || isAnimatingRef.current) return;
    const delta = touchStartYRef.current - e.changedTouches[0].clientY;
    touchStartYRef.current = null;
    if (delta > 60) goToStage(stageIndexRef.current + 1);
    if (delta < -60) goToStage(stageIndexRef.current - 1);
  }, [goToStage]);

  // Keyboard Handlers (Arrow navigation)
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (isAnimatingRef.current) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown') {
      e.preventDefault();
      goToStage(stageIndexRef.current + 1);
    } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
      e.preventDefault();
      goToStage(stageIndexRef.current - 1);
    }
  }, [goToStage]);

  const stageContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = stageContainerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    el.addEventListener('touchstart', handleTouchStart, { passive: true });
    el.addEventListener('touchend', handleTouchEnd, { passive: true });
    return () => {
      el.removeEventListener('wheel', handleWheel);
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleWheel, handleTouchStart, handleTouchEnd]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const scrollToSection = useCallback((sectionId: string) => {
    const idx = STAGES.indexOf(sectionId as StageId);
    if (idx !== -1) goToStage(idx);
  }, [goToStage]);

  // Data fetching
  useEffect(() => {
    fetch('/api/datasets')
      .then(r => r.json())
      .then(data => {
        if (data.datasets?.length > 0) {
          setDatasets(data.datasets);
          setSelectedDataset(prev => prev || data.datasets[0].id);
        }
      }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedDataset) return;
    fetch(`/api/graph/points3d?dataset=${selectedDataset}`).then(r => r.ok ? r.json() : null).then(setPoints3dData).catch(() => setPoints3dData(null));
    fetch(`/api/graph/archipelago?dataset=${selectedDataset}`).then(r => r.ok ? r.json() : null).then(setArchipelagoData).catch(() => setArchipelagoData(null));
    fetch(`/api/graph/citation?dataset=${selectedDataset}`).then(r => r.ok ? r.json() : null).then(setCitationData).catch(() => setCitationData(null));
    fetch(`/api/gaps/detected?dataset=${selectedDataset}`).then(r => r.ok ? r.json() : null).then(d => setDetectedGaps(d?.gaps ?? [])).catch(() => setDetectedGaps([]));
    fetch(`/api/gaps/narrated?dataset=${selectedDataset}`).then(r => r.ok ? r.json() : null).then(d => {
      if (d?.gaps?.length > 0) { setNarratedGaps(d.gaps); setSelectedGapTitle(d.gaps[0].title); }
      else setNarratedGaps([]);
    }).catch(() => setNarratedGaps([]));
  }, [selectedDataset]);

  const handleTriggerRun = async (query: string, maxResults: number) => {
    setIsRunning(true);
    setProgressEvents([]);
    setPipelineError(null);
    try {
      const response = await fetch('/api/pipeline/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, max_results: maxResults }),
      });
      if (!response.ok) throw new Error(`Pipeline failed: ${response.statusText}`);
      const reader = response.body?.getReader();
      if (!reader) return;
      const decoder = new TextDecoder();
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.replace('data: ', '').trim();
          if (!jsonStr) continue;
          try {
            const event: PipelineProgressEvent = JSON.parse(jsonStr);
            setProgressEvents(prev => [...prev, event]);
            if (event.is_terminal) {
              setIsRunning(false);
              if (event.dataset_id) {
                setSelectedDataset(event.dataset_id);
                scrollToSection('timeline');
              }
            }
          } catch { }
        }
      }
    } catch (err: any) {
      setPipelineError(err.message || 'Pipeline failed.');
      setIsRunning(false);
    }
  };

  const handleSelectGapForGrant = (gapTitle: string) => {
    setSelectedGapTitle(gapTitle);
    scrollToSection('grant');
  };

  // Inline Style Generator for Zero-Collision Staging
  const getStageStyle = (state: StageDisplayState): React.CSSProperties => {
    if (state === 'hidden') {
      return {
        display: 'none',
      };
    }
    const base: React.CSSProperties = {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      transition: 'opacity 0.45s cubic-bezier(0.16, 1, 0.3, 1)',
      willChange: 'opacity',
    };
    if (state === 'active') {
      return { ...base, opacity: 1, pointerEvents: 'auto', zIndex: 10 };
    }
    if (state === 'entering') {
      return { ...base, opacity: 1, pointerEvents: 'none', zIndex: 10 };
    }
    if (state === 'exiting') {
      return { ...base, opacity: 0, pointerEvents: 'none', zIndex: 5 };
    }
    return base;
  };

  return (
    <>
      {/* Universal Atmospheric WebGL Canvas */}
      <UniversalBackground
        viewMode={viewMode}
        isTransitioning={isTransitioning}
        activeTab={activeTab}
        selectedClusterId={selectedClusterId}
        onSelectCluster={setSelectedClusterId}
        activeLayer={activeLayer}
        points3dData={points3dData}
        scrollProgress={STAGE_PROGRESS[activeTab]}
      />

      {/* Master Navigation Header */}
      <Header
        viewMode={viewMode}
        activeTab={activeTab}
        onSelectTab={scrollToSection}
        onReturnToHero={() => scrollToSection('hero')}
        onLaunchStudio={() => scrollToSection('archipelago')}
      />

      {/* Main Viewport Stage Container */}
      <div
        ref={stageContainerRef}
        style={{
          position: 'fixed',
          top: '60px',
          left: 0,
          right: 0,
          bottom: 0,
          overflow: 'hidden',
          zIndex: 2,
        }}
      >
        {/* 00 — Hero Observatory & Search Deck */}
        {stageStates[0] !== 'hidden' && (
          <div style={getStageStyle(stageStates[0])}>
            <HeroSection
              onLaunch={(tab) => scrollToSection(tab || 'archipelago')}
              isRunning={isRunning}
              progressEvents={progressEvents}
              pipelineError={pipelineError}
              onSearch={(searchQuery, corpusSize, datasetId) => {
                setPipelineError(null);
                if (datasetId) {
                  setSelectedDataset(datasetId);
                  scrollToSection('archipelago');
                  return;
                }
                handleTriggerRun(searchQuery, corpusSize || 300);
                scrollToSection('archipelago');
              }}
            />
          </div>
        )}

        {/* 01 — Epistemic Archipelago & Algorithmic Gap Matrix */}
        {stageStates[1] !== 'hidden' && (
          <div style={getStageStyle(stageStates[1])}>
            <OmniScopeStudio
              data3d={points3dData}
              onNavigateToGrant={handleSelectGapForGrant}
              selectedClusterId={selectedClusterId}
              onSelectCluster={setSelectedClusterId}
              activeLayer={activeLayer}
              gaps={detectedGaps}
            />
          </div>
        )}

        {/* 02 — SPLC Citation Lineage & Epistemic Journey */}
        {stageStates[2] !== 'hidden' && (
          <div style={{ ...getStageStyle(stageStates[2]), overflowY: 'auto' }}>
            <CitationTimeline data={citationData} />
          </div>
        )}

        {/* 03 — AI Grant Studio & Operational Hypotheses */}
        {stageStates[3] !== 'hidden' && (
          <div style={{ ...getStageStyle(stageStates[3]), overflowY: 'auto' }}>
            <GrantStudio
              narratedGaps={narratedGaps}
              selectedGapTitle={selectedGapTitle}
            />
          </div>
        )}

        {/* Vertical Stage Navigation Indicator (Right Edge) */}
        <nav
          aria-label="Platform Stage Navigation"
          style={{
            position: 'absolute',
            right: '20px',
            top: '50%',
            transform: 'translateY(-50%)',
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            zIndex: 40,
          }}
        >
          {STAGES.map((stageId, i) => {
            const isActive = i === stageIndex;
            return (
              <button
                key={stageId}
                onClick={() => goToStage(i)}
                title={STAGE_LABELS[stageId]}
                className="group relative flex items-center justify-center p-1 focus:outline-none"
              >
                <div
                  style={{
                    width: isActive ? '6px' : '4px',
                    height: isActive ? '26px' : '6px',
                    borderRadius: '3px',
                    backgroundColor: isActive ? '#ff4300' : 'rgba(255, 255, 255, 0.28)',
                    boxShadow: isActive ? '0 0 12px rgba(255, 67, 0, 0.6)' : 'none',
                    transition: 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
                  }}
                  className="group-hover:bg-[#ff4300] transition-colors"
                />
                {/* Floating Tooltip */}
                <span className="absolute right-6 px-2 py-1 rounded bg-[#080b11]/90 border border-white/10 text-[10px] font-mono text-zinc-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl">
                  {STAGE_LABELS[stageId]}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </>
  );
};

export default App;